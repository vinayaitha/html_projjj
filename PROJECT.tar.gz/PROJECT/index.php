<?php 
	if (isset($_POST["register"])) {
		$username = $_POST["username"];
		echo "Welcome  ".$username;
	}

?>