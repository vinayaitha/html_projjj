<?php

 $servername = 'localhost';
 $username ='root';
 $password='';
 $db     ='vinay';

 $conn = new mysqli($servername,$username,$password,$db);
 
 if($conn->connect_error){
  die("connection failed : ".$connect->connect_error);
}

?>

