<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
   

    <title>SignIn</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/component.css">
    <link rel="stylesheet" href="css/custom-styles.css">
    <link rel="stylesheet" href="css/font-awesome.css">
	
     
	 <link rel="stylesheet" href="css/demo.css">
    <link rel="stylesheet" href="css/font-awesome-ie7.css">

      <script src="js/jquery.mobilemenu.js"></script>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script>
    $(document).ready(function(){
        $('.menu').mobileMenu();
    });
  </script>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;

}
div.a1{
width:100%;
height:70%;
}
input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    width:150px;
}

input[type=submit]:hover {
    background-color: #45a049;
}
div.aa{
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
</style>
 
  </head>

  <body>
    <div class="header-wrapper">
      <div class="site-name">
        <h1>NOTARY HUB</h1>
        <h2>Notary Document Repository Management System</h2>
      </div>
    </div>
    <div class="menu">
      <div class="navbar">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <i class="fw-icon-th-list"></i>
            </button>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="index.html">Home</a></li>
              <li><a href="test1.html">About</a></li>
              <li><a href="test1.html">Services</a></li>
              <li><a href="test1.html">Solutions</a></li>
              <li><a href="test1.html">Help</a></li>
              <li><a href="test1.html">Contactus</a></li>
               <li><a href="signup.html">Signup</a></li>
 
    
            </ul>
          </div><!--/.navbar-collapse -->
        </div>
      </div>
      <div class="mini-menu">
            <label>
          <select class="selectnav">
            <option value="#" selected="">Home</option>
            <option value="#">About</option>
            <option value="#">→ Another action</option>
            <option value="#">→ Something else here</option>
            <option value="#">→ Another action</option>
            <option value="#">→ Something else here</option>
            <option value="#">Services</option>
            <option value="#">Work</option>
            <option value="#">Contact</option>
          </select>
          </label>
          </div>
    </div>
</div>
	<div style="height=20%">



           </div>
<div>
<div class="a1">
     <form id="form1" method="POST" >

    <div>              

    </div> 

    <h2 align="center"> SIGN IN</h2>

    <table id="table1";  align="center">

       <tr>
              <td  align="right" class="style1">EmailId</td>

              <td class="style1" ><input type="text" name="fname" placeholder="Your name mailid.."/></td>

       </tr>
      
       
       <tr>

              <td align="right">Password</td>

              <td><input type="text" name="pwd" placeholder="Enter your password" /></td>

       </tr>

       
   

     

</table> 
    <center>
    <input type="submit" name='submit' value="SIGN IN">
   </center>
    </form>
</div>

</div>
</div>

</div>

<?php
  if(isset($_POST['submit'])){
          include("connectDB.php");
        session_start();
     $user = $_POST['fname'];
     $pass = $_POST['pwd'];


 $sql = "SELECT fname FROM SIGNUP WHERE (email='$user' OR fname='$user') AND password='$pass'";

$result=$conn->query($sql);

while ($row = mysql_fetch_array ($result)){
$name=$row['fname'];
}
echo $name;
$_SESSION['user']=$name;

 
if($result->num_rows > 0 ){
 echo "<script language='text/javascript' type='text/javascript'> location.href ='DashBoard.php' </script>";
}

 else
    {
         echo "<script type='text/javascript'> alert('username or password Invalid ') </script>";
}
}
?>
        
</body>
</html>
