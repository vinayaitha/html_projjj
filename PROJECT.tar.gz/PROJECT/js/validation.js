function validateform(){  
var fname=document.myform.fname.value;  
var lname=document.myform.lname.value; 
var email=document.myform.email.value;
var password=document.myform.pwd.value;
var password1=document.myform.confpwd.value; 
var mobile=document.myform.mobile.value; 
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

var name_error = document.getElementById("div1");
var name_error1 = document.getElementById("div2");
var name_error2 = document.getElementById("div3");
var name_error3 = document.getElementById("div4");
  
if (fname==null || fname==""){  
   document.getElementById("div1").innerHTML="first Name can't be blank";   
  return false;  
}
if (lname==null || lname==""){  
  document.getElementById("div2").innerHTML="Last Name can't be blank";    
  return false;  
}
if (email==null || email==""){  
  document.getElementById("div3").innerHTML="email can't be blank";    
  return false;  
}
if(email.match(mailformat))  

{  

 if(password.length<6){  
  document.getElementById("div4").innerHTML="Password must be at least 6 characters.";  
  return false;  
  }  
if(isNaN(mobile)){  
  document.getElementById("div5").innerHTML="mobile Number Must Be Numbers";  
  return false;  
  } 
if(mobile.length<10){  
  document.getElementById("div5").innerHTML="enter valid number";  
  return false;  
  }

}  

else 

{  

document.getElementById("div3").innerHTML="You have entered an invalid email";  
return false;  

}  


}  
