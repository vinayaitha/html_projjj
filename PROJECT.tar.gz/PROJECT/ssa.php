<?php
include("connectDB.php");
$user = "vinay";
$pass = "123456";


$sql = "SELECT fname FROM SIGNUP WHERE (email='$user' OR fname='$user') AND password='$pass'";

$result=$conn->query($sql);

#echo $result;

if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
      $x= $row["fname"];

   }
} else {
   echo "0 results";
}
echo $sx;
#while ($row = mysql_fetch_array ($result)){
#$name=$row['fname'];
#echo $name;
#}
#echo $name;

?>
